package Controlador;

import Controlador.exception.AdyacenciaExepcion;
import java.io.Serializable;
import lista.controlador.Lista;
import lista.controlador.PilaCola;

/**
 *
 * @author usuario
 */
public abstract class Grafo implements Serializable {

    protected Integer visitados[] = {0};
    protected int ordenVisita;
    protected PilaCola q;
    private Integer[][] matrizAdy;
    private Integer[] camino;
    private Integer[] D;
    private Boolean[] F;

    /**
     * Es el numero de vertices del grafo
     *
     * @return Integer numero de vertices
     */
    public abstract Integer numVertices();

    /**
     * Es el numero de aristas del grafo
     *
     * @return Integer numero de aristas
     */
    public abstract Integer numAristas();

    /**
     * Permite ver si entre dos nodos hay conexion (arista)
     *
     * @param i Nodo incial
     * @param j Nodo final
     * @return true si estan conectados
     * @throws Exception Excepcion
     */
    public abstract Boolean existeArista(Integer i, Integer j) throws Exception;

    /**
     * Retorna el peso que hay entre dos vertices
     *
     * @param i Nodo incial
     * @param j Nodo final
     * @return Double peso de la arista
     */
    public abstract Double pesoArista(Integer i, Integer j);

    /**
     * Permite insertar arista sin peso
     *
     * @param i Nodo incial
     * @param j Nodo final
     */
    public abstract void insertarArista(Integer i, Integer j);

    /**
     * Permite insertar arista con peso
     *
     * @param i Nodo incial
     * @param j Nodo final
     * @param peso peso de la arista
     */
    public abstract void insertarArista(Integer i, Integer j, Double peso);

    /**
     * Listado de adycencias de un nodo
     *
     * @param i Nodo a listar sus adyacencias
     * @return Lista
     */
    public abstract Lista<Adyacencia> adyacentes(Integer i);

    @Override
    public String toString() {
        String grafo = "";
        for (int i = 1; i <= numVertices(); i++) {
            grafo += "Vertice " + i;
            Lista<Adyacencia> lista = adyacentes(i);
            for (int j = 0; j < lista.tamanio(); j++) {
                Adyacencia aux = lista.consultarDatoPosicion(j);

                if (aux.getPeso().toString().equalsIgnoreCase(String.valueOf(Double.NaN))) {
                    grafo += " --Vertice destino " + aux.getDestino() + "-- SP ";
                } else {
                    grafo += " --Vertice destino " + aux.getDestino() + "-- Peso " + aux.getPeso() + "--";
                }

            }
            grafo += "\n";
        }
        return grafo;
    }

    public Lista caminoMinimo(Integer verticeI, Integer verticeF) throws AdyacenciaExepcion {
        Lista<Integer> caminos = new Lista<>();

        Lista<Double> listarPesos = new Lista<>();
        Integer inicial = verticeI;
        caminos.insertarNodo(inicial);
        Boolean finalizar = false;
        while (!finalizar) {
            Lista<Adyacencia> adyacencias = adyacentes(inicial);
            if (adyacencias == null) {
                throw new AdyacenciaExepcion("No existe adyacencias");
            }

            Double peso = 100000000.0;
            Integer T = -1;//aux Destino
            for (int i = 0; i < adyacencias.tamanio(); i++) {
                Adyacencia ad = adyacencias.consultarDatoPosicion(i);

                if (!estaEnCamino(caminos, ad.getDestino())) {
                    Double pesoArista = ad.getPeso();
                    if (verticeF.intValue() == ad.getDestino().intValue()) {
                        T = ad.getDestino();
                        peso = pesoArista;
                        break;
                    } else if (pesoArista < peso) {
                        T = ad.getDestino();
                        peso = pesoArista;
                    }
                }

            }
            listarPesos.insertarNodo(peso);
            caminos.insertarNodo(T);
            inicial = T;
            if (verticeF.intValue() == inicial.intValue()) {
                finalizar = true;
            }
        }

        return caminos;
    }

    public boolean estaEnCamino(Lista<Integer> lista, Integer vertice) {
        Boolean band = false;
        for (int i = 0; i < lista.tamanio(); i++) {
            if (lista.consultarDatoPosicion(i).intValue() == vertice.intValue()) {
                band = true;
                break;
            }
        }
        return band;
    }

    public Integer[] toArrayBusquedaPro() {
        Integer res[] = new Integer[numVertices() + 1];
        visitados = new Integer[numVertices() + 1];
        ordenVisita = 1;
        for (int i = 1; i <= numVertices(); i++) {
            visitados[i] = 0;
        }
        for (int i = 1; i <= numVertices(); i++) {
            if (visitados[i] == 0) {
                toArrayDFS(i, res);
            }
        }
        return res;
    }

    private void toArrayDFS(int origen, Integer[] res) {
        res[ordenVisita] = origen;
        visitados[origen] = ordenVisita++;
        Lista<Adyacencia> lista1 = adyacentes(origen);
        for (int i = 0; i < lista1.tamanio(); i++) {
            Adyacencia a = lista1.consultarDatoPosicion(i);
            if (visitados[a.getDestino()] == 0) {
                toArrayDFS(a.getDestino(), res);
            }
        }
    }

    public Integer[] toArrayBFS() {
        String tipo = "COLA";
        Integer res[] = new Integer[numVertices() + 1];
        visitados = new Integer[numVertices() + 1];
        ordenVisita = 1;
        q = new PilaCola(numAristas(), tipo);
        for (int i = 1; i <= numVertices(); i++) {
            visitados[i] = 0;
        }
        for (int i = 1; i <= numVertices(); i++) {
            if (visitados[i] == 0) {
                toArrayBFS(i, res);
            }
        }
        return res;
    }

    public void toArrayBFS(int origen, Integer[] res) {
        res[ordenVisita] = origen;
        visitados[origen] = ordenVisita++;
        q.queue(new Integer(origen));
        while (!q.estaVacia()) {
                int u = (int) q.dequeue();
            Lista<Adyacencia> lista = adyacentes(u);
            for (int i = 0; i < lista.tamanio(); i++) {
                Adyacencia a = lista.extraer();
                if (visitados[a.getDestino()] == 0) {
                    res[ordenVisita] = a.getDestino();
                    visitados[a.getDestino()] = ordenVisita++;
                    q.push(new Integer(a.getDestino()));
                }
            }
        }
    }
    public void Dijkstra(Integer origen){
        for (int i = 0; i < numVertices(); i++) {
            F[i] = false;
            D[i] = matrizAdy[origen][i];
            camino[i] = origen;
        }
        F[origen] = true;
        D[origen] = 0;
        for (int i = 1; i < numVertices(); i++) {
            int v = minimo();
            F[v] = true;
            for (int j = 1; j < numVertices(); j++) {
                if (!F[j]) {
                    if ((D[v] + matrizAdy[v][j]) < D[j]) {
                        D[j] = D[v] + matrizAdy[v][j];
                        camino[j] = v;
                    }
                }
            }
        }
    }
    private Integer minimo(){
        int v = 1;
        for (int i = 1; i < numVertices(); i++) {
            
        }
        return v;
    }
}
