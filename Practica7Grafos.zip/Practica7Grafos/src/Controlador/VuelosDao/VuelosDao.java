/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador.VuelosDao;

import Model.VuelosAviones;


/**
 *
 * @author usuario
 */
public class VuelosDao extends AdaptadorDao<VuelosAviones>{
    private VuelosAviones vuelos = new VuelosAviones();

    public VuelosDao() {
        super(VuelosAviones.class);
        listarGrafo();
    }

    public VuelosAviones getVuelos() {
        if(vuelos == null){
            vuelos = new VuelosAviones();
        }
        return vuelos;
    }

    public void setVuelos(VuelosAviones vuelos) {
        this.vuelos = vuelos;
    }
    
    public  Boolean guardar(){
        Integer aux = (getGrafo() !=null) ? getGrafo().numVertices()+1 : 1;
        vuelos.setId(new Long(String.valueOf(aux)));
        return guardar(vuelos);
    }
    
    public Boolean modificar(){
        return  modificar(vuelos);
    }

    public void setVuelos(VuelosDao vuelos) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Boolean busquedaProfundidad(){
        return busquedProfundidad(vuelos);
    }
}
