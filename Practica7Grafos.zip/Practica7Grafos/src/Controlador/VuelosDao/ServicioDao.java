/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador.VuelosDao;

import Controlador.GrafoEtiquetadoND;
import Model.VuelosAviones;

/**
 *
 * @author Home
 */
public class ServicioDao {
    private VuelosDao vuelosDao = new VuelosDao();

    public VuelosAviones getVuelo() {
        return vuelosDao.getVuelos();
    }
    public void fijarVuelo(VuelosAviones vuelos) {
        vuelosDao.setVuelos(vuelos);
    }

    public Boolean guardar() {
        return vuelosDao.guardar();
    }

    public void imprimirGrafoVuelos() {

        System.out.println(vuelosDao.getGrafo().toString());

    }

    public GrafoEtiquetadoND<VuelosAviones> getGrafo() {
        return vuelosDao.listarGrafo();
    }

    public GrafoEtiquetadoND<VuelosAviones> getGrafoObjeto() {
        return vuelosDao.getGrafo();
    }

    public Boolean actualizarGrafo(GrafoEtiquetadoND<VuelosAviones> grafoAux) {
        return vuelosDao.actualizarGrafo(grafoAux);
    }
//    public int [] buscarP(){
//        //return vuelosDao.getGrafo().toArrayBFS();
//    }

}
