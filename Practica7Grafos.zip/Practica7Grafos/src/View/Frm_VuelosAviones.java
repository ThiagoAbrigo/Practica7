/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Controlador.VuelosDao.ServicioDao;
import Controlador.exception.AdyacenciaExepcion;
import View.ModeloTabla.TableVuelos;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import lista.controlador.Lista;

/**
 *
 * @author Home
 */
public class Frm_VuelosAviones extends javax.swing.JDialog {
    private TableVuelos modelo = new TableVuelos();
    private ServicioDao sd = new ServicioDao();
    /**
     * Creates new form Frm_VuelosAviones
     */
    public Frm_VuelosAviones(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        limpiarDatos();
    }
    
    private void cargarTabla() {
        if (sd.getGrafo() != null) {
            modelo.setGrafoND(sd.getGrafo());
            tablevuelos.setModel(modelo);
            modelo.fireTableStructureChanged();
            tablevuelos.updateUI();
            //System.out.println(modelo.getColumnCount() + "---");
        } else {
            DefaultTableModel model = new DefaultTableModel(1, 1);
            tablevuelos.setModel(model);
            tablevuelos.updateUI();
            //System.out.println(modelo.getColumnCount());
        }
    }

    private void cargarCombos() {
        cbxorig.removeAllItems();
        cbxdestino.removeAllItems();
        if (sd.getGrafo() != null) {
            for (int i = 0; i < sd.getGrafo().numVertices(); i++) {
                String label = sd.getGrafo().obtenerEtiqueta(i + 1).toString();
                cbxorig.addItem(label);
                cbxdestino.addItem(label);
            }
        }
    }

    private void limpiarDatos() {
        txthoras.setText("");
        txtnombre.setText("");
        txtparadas.setText("");
        txtpais.setText("");
        sd.fijarVuelo(null);
        cargarTabla();
        cargarCombos();
    }
    
    private void agregarAdycencias() {
        if (sd.getGrafo() != null) {
            if (cbxdestino.getSelectedIndex() == cbxorig.getSelectedIndex()) {
                JOptionPane.showMessageDialog(null, "No se puede agrgar un mismo valor", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                //longitud x
                // latitud y
                Integer p1 = cbxorig.getSelectedIndex() + 1;
                Integer p2 = cbxdestino.getSelectedIndex() + 1;

                Double xCuadrado = Math.pow(sd.getGrafo().obtenerEtiqueta(p1).getParadas() - sd.getGrafo().obtenerEtiqueta(p2).getParadas(), 2);
                Double yCuadrado = Math.pow(sd.getGrafo().obtenerEtiqueta(p1).getHorasViaje() - sd.getGrafo().obtenerEtiqueta(p2).getHorasViaje(), 2);
                Double distancia = Math.sqrt(yCuadrado + xCuadrado);
                sd.getGrafo().insertarArista(p2, p2, distancia);
                //ps.getGrafo().obtenerCodigo(p1);
                if (sd.actualizarGrafo(sd.getGrafoObjeto())) {
                    JOptionPane.showMessageDialog(null, "Gracias Actualizar grafo", "OK", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No se puede agrgar un mismo valor", "Error", JOptionPane.ERROR_MESSAGE);
                }
                limpiarDatos();
            }

        } else {
            JOptionPane.showMessageDialog(null, "Faltan datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Boolean validarDatos() {
        return (txtparadas.getText().trim().length() > 0 && txthoras.getText().trim().length() > 0 && txtpais.getText().trim().length() > 0 && txtnombre.getText().trim().length() > 0);
    }
//    
//    public void generarCaminos() throws AdyacenciaExepcion {
//        if (cbxdestino.getSelectedItem() == cbxorig.getSelectedItem()) {
//            JOptionPane.showMessageDialog(null, "No se puede agregar un nuevo valor", "Error", JOptionPane.ERROR_MESSAGE);
//        } else {
//            Integer p1 = cbxorig.getSelectedIndex() + 1;
//            Integer[] camino = new Integer[sd.getGrafo().numVertices()];
//            camino = sd.getGrafo().toArrayDFS(p1);
//            System.out.println(camino[1]);
//            for (int i = 0; i < camino.length; i++) {
//                txtprofundidad.setText(sd.getGrafo().obtenerEtiqueta(Integer.parseInt(camino[i].toString())).toString() + "\n");
//            }
//
//        }
//
//    }

    private void agregar() {
        if (validarDatos()) {
            try {
                sd.getVuelo().setNombrePasajero(txtnombre.getText());
                sd.getVuelo().setParadas(Integer.parseInt(txtparadas.getText()));
                sd.getVuelo().setHorasViaje(Integer.parseInt(txthoras.getText()));
                sd.getVuelo().setPais(txtpais.getText());
                if (sd.guardar()) {
                    JOptionPane.showMessageDialog(null, "Se Guardo Correctamente", "OK", JOptionPane.INFORMATION_MESSAGE);
                    limpiarDatos();
                } else {
                    JOptionPane.showMessageDialog(null, "No se Pudo Guardar", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Faltan datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        txtnombre = new javax.swing.JTextField();
        txthoras = new javax.swing.JTextField();
        txtparadas = new javax.swing.JTextField();
        txtpais = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablevuelos = new javax.swing.JTable();
        cbxorig = new javax.swing.JComboBox<>();
        cbxdestino = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtprofundidad = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(null);

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setText("VUELOS DE AVIONES");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(220, 17, 166, 19);

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel2.setText("Nombre:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(28, 58, 67, 16);

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel3.setText("Horas:");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(341, 104, 67, 16);

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel4.setText("Paradas:");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(341, 62, 67, 16);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        jLabel5.setText("Pais:");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(28, 104, 67, 16);

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(384, 142, 72, 24);

        jButton2.setText("Ver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(525, 142, 57, 24);
        jPanel2.add(txtnombre);
        txtnombre.setBounds(101, 54, 151, 24);
        jPanel2.add(txthoras);
        txthoras.setBounds(414, 100, 151, 24);
        jPanel2.add(txtparadas);
        txtparadas.setBounds(414, 58, 151, 24);
        jPanel2.add(txtpais);
        txtpais.setBounds(101, 100, 151, 24);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 10, 640, 180);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(null);

        tablevuelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablevuelos);

        jPanel3.add(jScrollPane1);
        jScrollPane1.setBounds(10, 90, 472, 152);

        cbxorig.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel3.add(cbxorig);
        cbxorig.setBounds(540, 80, 80, 26);

        cbxdestino.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel3.add(cbxdestino);
        cbxdestino.setBounds(540, 140, 90, 26);

        jButton3.setText("Agregar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3);
        jButton3.setBounds(527, 193, 78, 24);

        jLabel6.setText("Origen");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(497, 88, 41, 16);

        jLabel7.setText("Destino");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(497, 141, 41, 16);

        txtprofundidad.setColumns(20);
        txtprofundidad.setRows(5);
        jScrollPane2.setViewportView(txtprofundidad);

        jPanel3.add(jScrollPane2);
        jScrollPane2.setBounds(15, 7, 223, 70);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(10, 200, 640, 250);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 660, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 660, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 460, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        setSize(new java.awt.Dimension(674, 497));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        agregar();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        new Frm_PresentarVueloGrafo(null, true, sd).setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        agregarAdycencias();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frm_VuelosAviones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frm_VuelosAviones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frm_VuelosAviones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frm_VuelosAviones.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Frm_VuelosAviones dialog = new Frm_VuelosAviones(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbxdestino;
    private javax.swing.JComboBox<String> cbxorig;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablevuelos;
    private javax.swing.JTextField txthoras;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtpais;
    private javax.swing.JTextField txtparadas;
    private javax.swing.JTextArea txtprofundidad;
    // End of variables declaration//GEN-END:variables
}
