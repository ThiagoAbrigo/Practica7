/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class VuelosAviones implements Serializable{
    private Long id;
    private String pais;
    private int horasViaje;
    private int paradas;
    private String nombrePasajero;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getHorasViaje() {
        return horasViaje;
    }

    public void setHorasViaje(int horasViaje) {
        this.horasViaje = horasViaje;
    }

    public int getParadas() {
        return paradas;
    }

    public void setParadas(int paradas) {
        this.paradas = paradas;
    }

    public String getNombrePasajero() {
        return nombrePasajero;
    }

    public void setNombrePasajero(String nombrePasajero) {
        this.nombrePasajero = nombrePasajero;
    }
    @Override
    public String toString() {
        return pais;
    }
}
